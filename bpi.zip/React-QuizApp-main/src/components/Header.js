//import ReactLogo from "./React_logo1.png"; // Import the image
//<img src={ReactLogo} alt="Reactlogo" />
function Header() {
  return (
    <header className="app-header">
      <h1>The Quiz</h1>
    </header>
  );
}

export default Header;
